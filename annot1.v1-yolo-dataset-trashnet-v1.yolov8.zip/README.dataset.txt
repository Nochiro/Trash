# annot1 > Yolo dataset trashnet v1
https://universe.roboflow.com/trashnet-annotations/annot1

Provided by a Roboflow user
License: CC BY 4.0

